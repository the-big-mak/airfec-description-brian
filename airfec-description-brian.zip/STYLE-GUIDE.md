## Style Guide

Refer to the [AirBnb Style Guide](https://github.com/airbnb/javascript).

