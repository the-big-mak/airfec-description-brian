import React from 'react';

const RenderNoContent = () => (
  <div>
  </div>
);

export default RenderNoContent;
