import React from 'react';

const DisplayedRules = props => (
  <div className="displayed-rule">
    {props.displayedRules}
  </div>
);

export default DisplayedRules;
