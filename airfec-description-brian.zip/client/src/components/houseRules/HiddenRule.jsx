import React from 'react';

const HiddenRule = props => (
  <div className="hidden-rule">
    {props.hiddenRule}
  </div>
);

export default HiddenRule;
