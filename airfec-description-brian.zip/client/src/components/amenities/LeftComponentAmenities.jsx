import React from 'react';

const LeftComponentAmenities = props => (
  <div className="amenity">
    {props.amenity}
  </div>
);


export default LeftComponentAmenities;
