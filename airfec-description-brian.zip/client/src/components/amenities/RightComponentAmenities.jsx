import React from 'react';

const RightComponentAmenities = props => (
  <div className="amenity">
    {props.amenity}
  </div>
);


export default RightComponentAmenities;
