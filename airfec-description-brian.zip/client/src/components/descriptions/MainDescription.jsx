import React from 'react';

const MainDescription = props => (
  <div>
    {props.main}
  </div>
);

export default MainDescription;
